weboffice
=========

WebOffice es una aplicación para Firefox OS basada en WebODF technology. que te permite leer cualquier archivo en formato OpenDocument almacenado en la memoria SD de tu dispositivo. OpenDocument es un formato de archivo abierto y estándar para el almacenamiento de documentos ofimáticos tales como hojas de cálculo, textos, gráficas y presentaciones.

Soporta Documentos con las extensiones .odt para documentos de texto, .ods para hojas de cálculo, .odp para presentaciones
